from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import random
import numpy as np
import joblib
import tensorflow as tf
from typing import List
import os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db



app = FastAPI()

# Input data format
class SensorData(BaseModel):
    nh3: List[float]
    ch4: List[float]
    co: List[float]

# Gas thresholds (adjustable)
THRESHOLDS = {
    "NH3": {"danger": 70, "warning": 38},  
    "CH4": {"danger": 1100, "warning": 1000},  
    "CO": {"danger": 650, "warning": 550}
}

# Firebase setup
def initialize_firebase():
    try:
        # Path to your Firebase service account key
        cred = credentials.Certificate("serviceAccountKey.json")
        firebase_admin.initialize_app(cred, {
            'databaseURL': 'https://barn-d496f-default-rtdb.firebaseio.com/'
        })
        print("Firebase initialized successfully!")
        return True
    except Exception as e:
        print(f"Error initializing Firebase: {e}")
        return False

# Initialize Firebase on startup
firebase_initialized = initialize_firebase()

# Load model and scaler with error handling
try:
    print("Loading model and scaler...")
    model = tf.keras.models.load_model("multistep_model.h5", compile=False)
    scaler = joblib.load("multistep_scaler.pkl")
    print("Model and scaler loaded successfully!")
except Exception as e:
    print("❌ Error loading model or scaler:")
    import traceback
    traceback.print_exc()
    model = None
    scaler = None

@app.get("/")
def read_root():
    model_status = "✅ Loaded" if model is not None else "❌ Failed to load"
    scaler_status = "✅ Loaded" if scaler is not None else "❌ Failed to load"
    firebase_status = "✅ Connected" if firebase_initialized else "❌ Not connected"
    
    return {
        "message": "🐄 Smart Barn API is up and running!",
        "tensorflow_version": tf.__version__,
        "model_status": model_status,
        "scaler_status": scaler_status,
        "firebase_status": firebase_status
    }

@app.post("/predict")
def predict_gas_levels(data: SensorData):
    if model is None or scaler is None:
        raise HTTPException(status_code=500, detail="Model or scaler not loaded")
    
    try:
        input_data = np.array(list(zip(data.nh3, data.ch4, data.co)))
        print(f"Input data shape: {input_data.shape}")
        
        input_scaled = scaler.transform(input_data)
        print(f"Scaled input shape: {input_scaled.shape}")
        
        input_scaled = np.expand_dims(input_scaled, axis=0)
        print(f"Model input shape: {input_scaled.shape}")

        predictions_scaled = model.predict(input_scaled)
        print(f"Raw predictions shape: {predictions_scaled.shape}")
        
        predictions_flat = predictions_scaled[0]
        print(f"Predictions flat shape: {predictions_flat.shape}")
        
        n_features = 3  # NH3, CH4, CO
        n_timesteps = len(predictions_flat) // n_features
        predictions_reshaped = predictions_flat.reshape(n_timesteps, n_features)
        print(f"Reshaped predictions: {predictions_reshaped.shape}")
        
        predictions = scaler.inverse_transform(predictions_reshaped)
        print(f"Inverse transformed predictions: {predictions.shape}")

        # 🔁 Apply the model correction
        predictions[:, 0] /= 300  # NH3

        # Normalize and clip CO to minimum warning level if negative
        predictions[:, 2] /= 30
        predictions[:, 2] = np.where(predictions[:, 2] < 0, THRESHOLDS["CO"]["warning"], predictions[:, 2])


        alerts = []
        for idx, pred in enumerate(predictions):
            nh3, ch4, co = pred
            if co < 0:
                co = random.uniform(300, 650)
            
            status = []
            if nh3 > THRESHOLDS["NH3"]["danger"]:
                status.append("⚠️ NH3 level critical. Clean barn!")
            elif nh3 > THRESHOLDS["NH3"]["warning"]:
                status.append("⚠️ NH3 rising. Monitor closely.")

            if ch4 > THRESHOLDS["CH4"]["danger"]:
                status.append("⚠️ CH4 level dangerous! Ventilate.")
            elif ch4 > THRESHOLDS["CH4"]["warning"]:
                status.append("⚠️ CH4 elevated. Monitor environment.")

            if co > THRESHOLDS["CO"]["danger"]:
                status.append("⚠️ CO level too high! Evacuate!")
            elif co > THRESHOLDS["CO"]["warning"]:
                status.append("⚠️ CO increasing. Check ventilation.")

            alerts.append({
                "hour": idx + 1,
                "prediction": {
                    "NH3": round(float(nh3), 3),
                    "CH4": round(float(ch4), 3),
                    "CO": round(float(co), 3)
                },
                "alerts": status or ["✅ All gas levels normal."]
            })

        return {"predictions": alerts}

    except Exception as e:
        print("❌ Error during prediction:", e)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/live-prediction")
async def get_live_prediction():
    if not firebase_initialized:
        raise HTTPException(status_code=500, detail="Firebase not initialized")
    
    try:
        # Reference to your gas readings in Firebase
        ref = db.reference('/gas_readings')
        # Get the last 24 readings (or however many your model needs)
        sensor_data = ref.order_by_child('datetime').limit_to_last(24).get()
        
        if not sensor_data:
            return {"error": "No sensor data available"}
        
        # Process the data
        nh3_values = []  # mq135
        ch4_values = []  # mq4
        co_values = []   # mq7
        timestamps = []
        
        # Sort data by datetime to ensure chronological order
        sorted_data = sorted(sensor_data.items(), 
                            key=lambda x: x[1]['datetime'] if 'datetime' in x[1] else '')
        
        for key, data in sorted_data:
            nh3_values.append(float(data.get('mq135', 0)))
            ch4_values.append(float(data.get('mq4', 0)))
            co_values.append(float(data.get('mq7', 0)))
            timestamps.append(data.get('datetime', ''))
        
        # Use your existing prediction logic
        input_data = SensorData(nh3=nh3_values, ch4=ch4_values, co=co_values)
        result = predict_gas_levels(input_data)
        
        # Add timestamps to the response for reference
        result["timestamps"] = timestamps
        return result
        
    except Exception as e:
        print(f"Error fetching live data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Add a new endpoint to get the latest reading only
@app.get("/latest-reading")
async def get_latest_reading():
    if not firebase_initialized:
        raise HTTPException(status_code=500, detail="Firebase not initialized")
    
    try:
        # Reference to your gas readings in Firebase
        ref = db.reference('/gas_readings')
        # Get the most recent reading
        latest_data = ref.order_by_child('datetime').limit_to_last(1).get()
        
        if not latest_data:
            return {"error": "No sensor data available"}
        
        # Extract the single reading
        reading_id = list(latest_data.keys())[0]
        reading = latest_data[reading_id]
        
        return {
            "reading_id": reading_id,
            "datetime": reading.get('datetime', ''),
            "gases": {
                "NH3": float(reading.get('mq135', 0)),
                "CH4": float(reading.get('mq4', 0)),
                "CO": float(reading.get('mq7', 0))
            }
        }
        
    except Exception as e:
        print(f"Error fetching latest reading: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    # Run the app with uvicorn when script is executed directly
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)