from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
import numpy as np
import pickle
import tensorflow as tf

# Load model and scaler
model = tf.keras.models.load_model("model/multistep_model.keras")
with open("multistep_scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

# Alert thresholds
THRESHOLDS = {
    "NH3": {"warning": 15, "danger": 25},
    "CH4": {"warning": 800, "danger": 1200},
    "CO": {"warning": 9, "danger": 35},
    "TEMP": {"warning": 32, "danger": 37},
    "RH": {"warning": 80, "danger": 90}
}

class SensorInput(BaseModel):
    data: List[List[float]]  # List of [NH3, CH4, CO, TEMP, RH] rows

app = FastAPI()

@app.post("/predict")
def predict(input: SensorInput):
    input_data = np.array(input.data)
    scaled_input = scaler.transform(input_data)
    X_input = np.expand_dims(scaled_input, axis=0)  # Add batch dimension

    predictions = model.predict(X_input)[0]  # Shape: (timesteps, features)
    alerts = []

    for idx, pred in enumerate(predictions):
        nh3, ch4, co, temp, rh = pred
        status = []

        if nh3 > THRESHOLDS["NH3"]["danger"]:
            status.append("⚠️ NH3 level critical. Clean barn!")
        elif nh3 > THRESHOLDS["NH3"]["warning"]:
            status.append("⚠️ NH3 rising. Monitor closely.")

        if ch4 > THRESHOLDS["CH4"]["danger"]:
            status.append("⚠️ CH4 level dangerous! Ventilate.")
        elif ch4 > THRESHOLDS["CH4"]["warning"]:
            status.append("⚠️ CH4 elevated. Monitor environment.")

        if co > THRESHOLDS["CO"]["danger"]:
            status.append("⚠️ CO level too high! Evacuate!")
        elif co > THRESHOLDS["CO"]["warning"]:
            status.append("⚠️ CO increasing. Check ventilation.")

        if temp > THRESHOLDS["TEMP"]["danger"]:
            status.append("🌡️ Temperature dangerously high. Cool the area!")
        elif temp > THRESHOLDS["TEMP"]["warning"]:
            status.append("🌡️ Temperature rising. Ensure ventilation.")

        if rh > THRESHOLDS["RH"]["danger"]:
            status.append("💧 Humidity too high! Risk of mold.")
        elif rh > THRESHOLDS["RH"]["warning"]:
            status.append("💧 Humidity elevated. Dehumidify.")

        alerts.append({
            "hour": idx + 1,
            "prediction": {
                "NH3": round(float(nh3), 3),
                "CH4": round(float(ch4), 3),
                "CO": round(float(co), 3),
                "TEMP": round(float(temp), 2),
                "RH": round(float(rh), 2),
            },
            "alerts": status or ["✅ All parameters normal."]
        })

    return {"forecasts": alerts}
